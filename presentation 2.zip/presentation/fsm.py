from pyfsm import FSM

# Initialise

fsm2 = FSM(initial='trash', transitions=[
    {'name': 'recoverPath', 'src': 'trash', 'dst': 'recover'},
    {'name': 'thrashPath', 'src': 'recover', 'dst': 'trash'},
])

fsm = FSM(initial='new', transitions=[
    {'name': 'age', 'src': 'new', 'dst': 'prevOldState'},
    {'name': 'goToOld', 'src': 'prevOldState', 'dst': 'old'},
    {'name': 'oldAgain', 'src': 'old', 'dst': 'old'},
    {'name': 'renew', 'src': 'old', 'dst': 'prevOldState'},
    {'name': 'backToNew', 'src': 'prevOldState', 'dst': 'new'},
    {'name': 'expire', 'src': 'old', 'dst': fsm2},
])

# Get current state
print(fsm.current)  # new

# Apply transition
fsm.apply('age')
print(fsm.current)  # prevOldState

fsm.apply('goToOld')
print(fsm.current)  # old

fsm.apply('oldAgain')  # old

# Check whether a transition can be applied
fsm.apply('expire')
print(fsm.current)  # fsm2
fsm2.apply('recoverPath')
print(fsm.current)  # recover 
print(fsm.can('renew'))  # False transition is possible 