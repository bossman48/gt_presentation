from goapy import Planner, Action_List

if __name__ == '__main__':
    import time

    _world = Planner('hungry', 'has_food', 'in_kitchen', 'tired', 'in_bed')
    _world.set_start_state(hungry=True, has_food=False, in_kitchen=False, tired=True, in_bed=False)
    _world.set_goal_state(tired=False)

    _actions = Action_List()
    _actions.add_condition('eat', hungry=True, has_food=True, in_kitchen=False)
    _actions.add_reaction('eat', hungry=False)
    _actions.add_condition('cook', hungry=True, has_food=False, in_kitchen=True)
    _actions.add_reaction('cook', has_food=True)
    _actions.add_condition('sleep', tired=True, in_bed=True)
    _actions.add_reaction('sleep', tired=False)
    _actions.add_condition('go_to_bed', in_bed=False, hungry=False)
    _actions.add_reaction('go_to_bed', in_bed=True)
    _actions.add_condition('go_to_kitchen', in_kitchen=False)
    _actions.add_reaction('go_to_kitchen', in_kitchen=True)
    _actions.add_condition('leave_kitchen', in_kitchen=True)
    _actions.add_reaction('leave_kitchen', in_kitchen=False)
    _actions.add_condition('order_pizza', has_food=False, hungry=True)
    _actions.add_reaction('order_pizza', has_food=True)
    _actions.set_weight('go_to_kitchen', 20)
    _actions.set_weight('order_pizza', 1)

    _world.set_action_list(_actions)
    
    _t = time.time()
    _path = _world.calculate()
    _took_time = time.time() - _t

    for path in _path:
        print(_path.index(path)+1, path['name'])

    print('\nTook:', _took_time)
"""
go_to_kitchen(in_kitchen=False) --> in_Kitchen=true;
eat(hungry=True, has_food=True, in_kitchen=False) --> hungry=false;
cook(hungry=True, has_food=False, in_kitchen=True) --> has_food=true;
sleep(tired=True, in_bed=True) --> tired=false;
go_to_bed(in_bed=False, hungry=False)  --> in_bed=true;
go_to_kitchen(in_kitchen=False) --> in_kitchen=true;
leave_kitchen(in_kitchen=true) --> in_kitchen=false;
order_pizza(has_food=False, hungry=True) --> has_Food=true;

Start State: hungry=True, has_food=False, in_kitchen=False, tired=True, in_bed=False

Goal State : tired=False

first of all:
    our state is tired, we want to be not tired; Because of that we must "sleep";  If we want to sleep, we must be not hungry;
    our state is hungry, we want to be not hungry; Because of that we must "eat";  If we want to eat, we must have food, in_kitchen is false;
    our state is has_food=false, we want to be has_food=true; Because of we must order_pizza or cook; we cannot cook, because we are not in kitchen. 
        So we should decide to order_pizza-> weight is important for selecting the state;
    So:
        Our Path is : order_pizza->eat->go_to_bed->sleep
        """